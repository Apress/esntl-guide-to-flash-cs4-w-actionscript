<?php

$fname = $_GET['fn'];
$lname = $_GET['ln'];

echo "Hello ".$fname." ".$lname."!";

?> 