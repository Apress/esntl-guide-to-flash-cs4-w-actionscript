<?php

$flashvar = array();

$flashvar['returningVariables'] = "Hello " . $_GET['name'];

$hello = http_build_query($flashvar);

echo $hello;



?>